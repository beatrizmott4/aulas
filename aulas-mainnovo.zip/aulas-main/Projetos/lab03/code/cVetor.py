# Lab 02 - Analise de Algoritmos de Busca
# Criando uma Classe Vetor

import sys
import random
import math
from datetime import datetime
import array

# *******************************************************
# ***                                                 ***
# *******************************************************
class cVetor:

# *******************************************************
    def __init__(self, n):

        self.vet        = [0] * n
        self.maxObjs    = n
        self.numObjs    = 0

# ******************************************************
    def getChave(self, pos):
        if (pos >= 0) and (pos < self.numObjs):
            return self.vet[pos]
        else:
            return -1
        
# *******************************************************
    def insere(self, chave):
        
        if self.numObjs < self.maxObjs:
            self.vet[self.numObjs] = chave
            self.numObjs += 1
            return True

        return False

# *******************************************************
    def ordena(self):
        
        if self.numObjs != 0:
            self.vet.sort()

# *******************************************************
    def __str__(self):

        outStr = "[ "

        if self.numObjs == 0:
            outStr += "Vetor Vazio ]"
        else:
            for i in range(0, self.numObjs-1):
                outStr += f'{self.vet[i]} , '

            outStr += f'{self.vet[self.numObjs-1]} ]'

        return outStr

# *******************************************************
    def buscaSeq(self, chave):

        for i in range(self.numObjs):
            if self.vet[i] == chave:
                return True, i
        return False, -1
        
        
# *******************************************************
    def buscaSeqOrd(self, chave):
        
        self.ordena()
        if self.numObjs < 0 or chave > self.vet[self.numObjs - 1]:
            return False, -1
        else:
            for i in range(self.numObjs):
                if self.vet[i] == chave:
                     return True, i

# *******************************************************
    def buscaBinIter(self, chave):
        
        self.ordena()
        inicio = 0
        fim = self.numObjs

        while inicio < fim:
            meio = (inicio + fim) // 2
            if self.vet[meio] == chave:
                return True, meio
            else:
                if self.vet[meio] > chave:
                    fim = meio - 1
                else:
                    inicio = meio + 1

        return False, -1

# *******************************************************
    def buscaBinRec(self, chave, inicio = 0, fim):
        
        if inicio > fim:
            return False, -1    
        else:
            meio = (inicio + fim)//2

            if self.vet[meio] == chave:
                return True, meio

            if self.vet[meio] > chave:
                return self.buscaBinRec(chave, inicio, meio - 1)
            else:
                return self.buscaBinRec(chave, meio + 1, fim)




        

# *******************************************************
# ***                                                 ***
# *******************************************************
if __name__ == '__main__':

    random.seed(int(datetime.now().strftime('%H%M%S')))

    n = 20
    
    v = cVetor(n)

    print(str(v))
        
    for i in range(0, n):
        v.insere( random.randint(0, 600))

    print(str(v))

    for i in range(0, n):
        chave = random.randint(0, 600)
        achei, pos = v.buscaSeq( chave )
        if (achei):
            print(f'Achei {v.getChave(pos)} na posicao {pos}')
        else:
            print(f'Nao achei a chave {chave}')


    v.ordena()

    print(f'Vetor ordenado:\n{str(v)}')

    for i in range(0, n):
        chave = random.randint(0, 600)
        achei, pos = v.buscaSeqOrd( chave )
        if (achei):
            print(f'Achei {v.getChave(pos)} na posicao {pos}')
        else:
            print(f'Nao achei a chave {chave}')

