[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/oQ5WTz_J)
# Lab04 - Algoritmos de Ordenação

Nesse Lab vamos analisar os algoritmos de *Ordenação*.

No código fornecido você encontra a implementação dos algoritmos de **Busca Sequencial** e **Busca Binária**, sendo esse último implementado em suas versões iterativa e recursiva.

O módulo principal gera um vetor com valores aleatórios e simula a ordenação usando vários algoritmos, computando estatísticas desses algoritmos, como número mínimo (melhor caso), máximo (pior caso) e médio de comparações executadas. Ao final do processo a média desses valores é comparada aos valores teóricos esperados dadas as complexidades dos respectivos algoritmos. 

Sua tarefa nesse Lab será implementar diferentes algoritmos e promover o mesmo tipo de análise feita para a busca. Ou seja, tentar executar várias vezes a ordenação e calcular os valores reais e os estimados pela teoria. Os algoritmos de ordenação que voce deve testar são:

1. por Seleção
2. . por Inserção
3. Método da Bolha (*Bubble Sort*)
4. Quicksort
5. Merge Sort

Para compreender de forma inituitiva o funcionamento de cada um desses algoritmos, acesse: 

https://www.cs.usfca.edu/~galles/visualization/ComparisonSort.html

e compare os métodos. Caso tenha dúvidas, consulte o professor ou os monitores pelo *Discord*. 

# Referencias Bibliográficas:

[1] 	Cormen,T.H., Leiserson,C.E., Rivest,R.L., Stein,C. **Algoritmos – Teoria e Prática**. Editora Campus. 3a. Edição, 2012.

[2] 	Canning, J., Broder, A., Lafore, R. **Data Structures & Algorithms in Python**. Addison-Wesley. 2022. 

