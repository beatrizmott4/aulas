import cVetor

numero = int(input("Digite um número: "))
objeto = cVetor.cVetor(numero)
