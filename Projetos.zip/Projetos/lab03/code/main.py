# ****************************************
# Lab 03 - Avaliando algoritmos de Busca
# ****************************************

import sys
import random
import math
from datetime import datetime

import cVetor

# *******************************************************
# ***                                                 ***
# *******************************************************
if __name__ == '__main__':

    random.seed(int(datetime.now().strftime('%H%M%S')))

    if (len(sys.argv) > 1):
        n = int(sys.argv[1])
    else:
        n = 20

    v = cVetor.cVetor(n)

    print(str(v))
        
    for i in range(0, n):
        v.insere( random.randint(0, n*10) )
        # print(str(v))

    for i in range(0, n*2):
        chave = random.randint(0, n*20)
        achei, pos = v.buscaSeq( chave )

        if (achei):
            print(f'Achei {v.getChave(pos)} na posicao {pos}')
        else:
            print(f'Nao achei a chave {chave}')

    print(str(v))

