[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/mblThxY5)
# Lab03 - Avaliando os Algoritmos de Busca

Nesse Lab vamos analisar os algoritmos de *Busca*, comparando suas complexidades teóricas com seu resultado prático.

## Objetivos:

1. Aprofundar o entendimento do conceito de analise de complexidade;
2. Avaliar um algoritmo e associa-lo as principais classes de complexidade apresentadas durante as aulas;
3. Reforçar o conceito de TAD e sua implementação na liguagem Python, na forma de Classe e Objetos;
4. Desenvolver versões iterativas e recursivas de um mesmo algoritmo.

## Exercícios:

1. Analise o módulo *cVetor.py* disponível nesse Lab. Rode seu código de teste e verifique o resultado. 

2. Implemente na função **buscaSeq** o *Algoritmo de Busca Sequencial*. A função recebe uma chave de busca e verifica se há uma ocorrência dessa chave no vetor. A função deve retornar a posição em que a primeira ocorrência da chave foi encontrada e o número de comparações necessárias para essa busca.

3. Implemente na função **buscaSeqOrd** o *Algoritmo de Busca Sequencial Ordenada*. Como o nome sugere, presume-se que **o vetor está ordenado**. Ela também recebe uma chave de busca e verifica se há uma ocorrência dessa chave no vetor, retornando a posição em que a primeira ocorrência da chave foi encontrada e o número de comparações necessárias para essa busca. 

4. Implemente na função **buscaBin** o *Algoritmo de Busca Binária* em sua versão iterativa (sem recursividade). Essa função também presume que **o vetor está ordenado**, e recebe uma chave de busca, verificando se há uma ocorrência dessa chave no vetor, retornando sua posição e o número de comparações necessárias para essa busca. 

5. Analise com calma o *Algoritmo de Busca Binária* e tente identificar uma característica recursiva nele. 

6. Uma vez identificado o processo recursivo da *Busca Binária*, implemente a função **buscaBinRec**, versão recursiva da função **buscaBin**. 

	Até aqui você deve ter testado suas novas funções dentro do escopo do próprio módulo. Vamos agora fazer a análise comparativa desses algoritmos de uma forma mais sistemática.

7. Construa um programa em *Python*, utilizando como base o arquivo **main.py**. Nesse programa você deve produzir estatísticas da execução de cada função que criou nos itens acima. Ou seja, produzir diferentes arranjos de chaves dentro do vetor e testar várias operações de busca, contabilizando o **Melhor Caso**, **Pior Caso** e **Caso Médio**. 

8. Para cada teste, compute em função do número de elementos do vetor os valores teóricos esperados para os mesmos **Melhor Caso**, **Pior Caso** e **Caso Médio**. Compare os resultados e veja se a teoria e prática estão de acordo. 

> Lembre-se de que para que essas análises sejam precisas é necessário ter-se um número razoável de chaves no vetor e de repetições do experimento.  

# Referências:

[1] Cormen,T.H., Leiserson,C.E., Rivest,R.L., Stein,C. **Algoritmos – Teoria e Prática**. Editora Campus. 4ª Edição, 2024.

[2] Canning, J., Broder, A., Lafore, R. **Data Structures & Algorithms in Python**. Addison-Wesley. 2022. 

[3] Galles, D., [**Searching Sorted List**](https://www.cs.usfca.edu/~galles/visualization/Search.html)
